import { pgTable, text, serial, integer, boolean, timestamp, date, time } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Worker Types - for custom worker categories
export const workerTypes = pgTable("worker_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  color: text("color").notNull().default("#3b82f6"), // Default blue color
  userId: integer("user_id").notNull(), // reference to the user who created this type
});

export const insertWorkerTypeSchema = createInsertSchema(workerTypes).pick({
  name: true,
  description: true,
  color: true,
  userId: true,
});

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  avatar: text("avatar"),
  googleId: text("google_id").unique(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
  avatar: true,
  googleId: true,
});

// Workers
export const workers = pgTable("workers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  type: text("type").notNull(), // general, specialized, supervisor
  userId: integer("user_id").notNull(), // reference to the user who added this worker
});

export const insertWorkerSchema = createInsertSchema(workers).pick({
  name: true,
  email: true,
  phone: true,
  type: true,
  userId: true,
});

// Worker Availability
export const availability = pgTable("availability", {
  id: serial("id").primaryKey(),
  workerId: integer("worker_id").notNull(),
  date: date("date").notNull(),
  isAvailable: boolean("is_available").notNull(),
  startTime: time("start_time"),
  endTime: time("end_time"),
  notes: text("notes"),
});

export const insertAvailabilitySchema = createInsertSchema(availability).pick({
  workerId: true,
  date: true,
  isAvailable: true,
  startTime: true,
  endTime: true,
  notes: true,
});

// Shifts
export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location"),
  date: date("date").notNull(),
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  notes: text("notes"),
  userId: integer("user_id").notNull(), // reference to the user who created this shift
});

export const insertShiftSchema = createInsertSchema(shifts).pick({
  name: true,
  location: true,
  date: true,
  startTime: true,
  endTime: true,
  notes: true,
  userId: true,
});

// Shift Requirements
export const shiftRequirements = pgTable("shift_requirements", {
  id: serial("id").primaryKey(),
  shiftId: integer("shift_id").notNull(),
  workerType: text("worker_type").notNull(), // general, specialized, supervisor
  count: integer("count").notNull(),
});

export const insertShiftRequirementSchema = createInsertSchema(shiftRequirements).pick({
  shiftId: true,
  workerType: true,
  count: true,
});

// Shift Assignments
export const shiftAssignments = pgTable("shift_assignments", {
  id: serial("id").primaryKey(),
  shiftId: integer("shift_id").notNull(),
  workerId: integer("worker_id").notNull(),
});

export const insertShiftAssignmentSchema = createInsertSchema(shiftAssignments).pick({
  shiftId: true,
  workerId: true,
});

// Activities (for activity log)
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  activityType: text("activity_type").notNull(), // upload, edit, publish
  description: text("description").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  userId: true,
  activityType: true,
  description: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type WorkerType = typeof workerTypes.$inferSelect;
export type InsertWorkerType = z.infer<typeof insertWorkerTypeSchema>;

export type Worker = typeof workers.$inferSelect;
export type InsertWorker = z.infer<typeof insertWorkerSchema>;

export type Availability = typeof availability.$inferSelect;
export type InsertAvailability = z.infer<typeof insertAvailabilitySchema>;

export type Shift = typeof shifts.$inferSelect;
export type InsertShift = z.infer<typeof insertShiftSchema>;

export type ShiftRequirement = typeof shiftRequirements.$inferSelect;
export type InsertShiftRequirement = z.infer<typeof insertShiftRequirementSchema>;

export type ShiftAssignment = typeof shiftAssignments.$inferSelect;
export type InsertShiftAssignment = z.infer<typeof insertShiftAssignmentSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
