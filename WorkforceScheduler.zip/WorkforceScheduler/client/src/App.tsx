import { Switch, Route, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Schedule from "@/pages/Schedule";
import Workers from "@/pages/Workers";
import Uploads from "@/pages/Uploads";
import Settings from "@/pages/Settings";
import Login from "@/pages/Login";
import Landing from "@/pages/Landing";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useState, useEffect } from "react";

function App() {
  const [location, setLocation] = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 1024);

  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/current"],
    retry: false,
  });

  // Authentication redirect effect - must be defined before conditional returns
  useEffect(() => {
    if (!isLoading) {
      // Redirect to login if not authenticated and trying to access protected routes
      if (!user && !["/login", "/", "/landing"].includes(location)) {
        setLocation("/");
      }
      // If on login page and already authenticated, redirect to dashboard
      else if (user && ["/login", "/landing", "/"].includes(location) && location !== "/dashboard") {
        setLocation("/dashboard");
      }
    }
  }, [user, location, setLocation, isLoading]);

  // Close sidebar on mobile when changing routes
  useEffect(() => {
    if (window.innerWidth < 1024) {
      setIsSidebarOpen(false);
    }
  }, [location]);

  // Handle responsive sidebar
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(true);
      } else {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Display landing page for root URL when not authenticated
  if (!user && location === "/") {
    return (
      <TooltipProvider>
        <Toaster />
        <Landing />
      </TooltipProvider>
    );
  }

  // Login page doesn't have the main layout
  if (location === "/login") {
    return (
      <TooltipProvider>
        <Toaster />
        <Login />
      </TooltipProvider>
    );
  }

  return (
    <TooltipProvider>
      <Toaster />
      <div className="flex h-screen">
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)}
          user={user as any}
        />
        
        <main className="flex-1 overflow-auto">
          <Header 
            onOpenSidebar={() => setIsSidebarOpen(true)}
            title={getPageTitle(location)}
          />
          
          <Switch>
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/" component={Dashboard} />
            <Route path="/schedule" component={Schedule} />
            <Route path="/workers" component={Workers} />
            <Route path="/uploads" component={Uploads} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </Switch>
          
          {/* Floating Action Button */}
          <Button 
            size="icon" 
            className="fixed right-6 bottom-6 w-14 h-14 rounded-full shadow-lg"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </main>
      </div>
    </TooltipProvider>
  );
}

function getPageTitle(location: string): string {
  switch (location) {
    case "/":
    case "/dashboard":
      return "Dashboard";
    case "/schedule":
      return "Shifts";
    case "/workers":
      return "Workers";
    case "/uploads":
      return "Uploads";
    case "/settings":
      return "Settings";
    default:
      return "Dashboard";
  }
}

export default App;
