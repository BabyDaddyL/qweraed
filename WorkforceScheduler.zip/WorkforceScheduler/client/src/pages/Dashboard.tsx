import { useState } from "react";
import ActionCard from "@/components/dashboard/ActionCard";
import Calendar from "@/components/dashboard/Calendar";
import ActivityList from "@/components/dashboard/ActivityList";
import UploadModal from "@/components/modals/UploadModal";
import RequirementsModal from "@/components/modals/RequirementsModal";
import { useLocation } from "wouter";
import { Upload, CalendarDays, ClipboardList } from "lucide-react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isRequirementsModalOpen, setIsRequirementsModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  const handleUploadClick = () => {
    setIsUploadModalOpen(true);
  };

  const handleScheduleClick = () => {
    setLocation("/schedule");
  };

  const handleRequirementsClick = () => {
    setIsRequirementsModalOpen(true);
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setIsRequirementsModalOpen(true);
  };

  return (
    <div className="p-6">
      {/* Quick Actions */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionCard
            title="Upload Availability"
            description="Upload worker availability from Excel"
            icon={Upload}
            buttonText="Upload Excel"
            onClick={handleUploadClick}
          />
          <ActionCard
            title="Create Schedule"
            description="Create or edit worker schedules"
            icon={CalendarDays}
            buttonText="Manage Schedule"
            onClick={handleScheduleClick}
          />
          <ActionCard
            title="Shift Requirements"
            description="Define worker requirements for shifts"
            icon={ClipboardList}
            buttonText="Set Requirements"
            onClick={handleRequirementsClick}
          />
        </div>
      </div>
      
      {/* Schedule Overview */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-800">Current Schedule</h3>
        </div>
        <Calendar onDateClick={handleDateClick} />
      </div>
      
      {/* Recent Activity */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Recent Activity</h3>
        <ActivityList />
      </div>
      
      {/* Modals */}
      <UploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)}
      />
      <RequirementsModal 
        isOpen={isRequirementsModalOpen} 
        onClose={() => setIsRequirementsModalOpen(false)}
        date={selectedDate}
      />
    </div>
  );
}
