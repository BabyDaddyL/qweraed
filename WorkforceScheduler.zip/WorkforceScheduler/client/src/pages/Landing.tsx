import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { 
  Calendar, 
  Users, 
  FileSpreadsheet, 
  Shield, 
  CheckCircle,
  ArrowRight
} from "lucide-react";

export default function Landing() {
  const [, setLocation] = useLocation();
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <nav className="container mx-auto flex justify-between items-center py-6 px-4">
          <div className="flex items-center space-x-2">
            <div className="bg-white p-2 rounded-full">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <span className="text-xl font-bold">StaffSync</span>
          </div>
          <Button 
            variant="outline" 
            className="bg-white text-blue-600 hover:bg-blue-50"
            onClick={() => setLocation("/login")}
          >
            Login
          </Button>
        </nav>
        
        <div className="container mx-auto px-4 py-20 md:py-32 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Streamline Your Workforce Management
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Effortlessly schedule shifts, manage worker availability, and optimize your team's performance with our intuitive platform.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                size="lg" 
                className="bg-white text-blue-600 hover:bg-blue-50"
                onClick={() => setLocation("/login")}
              >
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 shadow-2xl max-w-lg">
              <div className="grid grid-cols-7 gap-2">
                {Array.from({ length: 7 }).map((_, i) => (
                  <div key={i} className="text-center text-sm font-medium">
                    {['S', 'M', 'T', 'W', 'T', 'F', 'S'][i]}
                  </div>
                ))}
                {Array.from({ length: 35 }).map((_, i) => (
                  <div 
                    key={i + 7} 
                    className={`
                      h-10 w-10 rounded-full flex items-center justify-center text-sm
                      ${[9, 17, 22, 23].includes(i) ? 'bg-blue-500 text-white' : ''}
                      ${i === 15 ? 'bg-green-500 text-white' : ''}
                      ${i === 25 ? 'bg-purple-500 text-white' : ''}
                    `}
                  >
                    {i + 1}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Powerful Features to Streamline Your Workflow</h2>
          
          <div className="grid md:grid-cols-3 gap-10">
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="bg-blue-100 p-3 rounded-full inline-flex mb-6">
                <Calendar className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Smart Scheduling</h3>
              <p className="text-gray-600">
                Create and manage shifts with ease. View schedules by month or week, and quickly add requirements for any day.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="bg-green-100 p-3 rounded-full inline-flex mb-6">
                <FileSpreadsheet className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Excel Integration</h3>
              <p className="text-gray-600">
                Seamlessly import worker availability from Excel spreadsheets, saving time and reducing input errors.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="bg-purple-100 p-3 rounded-full inline-flex mb-6">
                <Users className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Worker Management</h3>
              <p className="text-gray-600">
                Create custom worker types, manage your team, and ensure the right people are assigned to the right shifts.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Why Choose StaffSync</h2>
          
          <div className="grid md:grid-cols-2 gap-10">
            <div className="flex items-start">
              <div className="mr-4 mt-1">
                <CheckCircle className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Save Time and Resources</h3>
                <p className="text-gray-600">
                  Reduce the hours spent on scheduling and management. Our platform automates the tedious parts, letting you focus on what matters.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="mr-4 mt-1">
                <CheckCircle className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Increase Efficiency</h3>
                <p className="text-gray-600">
                  Ensure optimal staffing levels for every shift. Never be understaffed or waste resources on overstaffing again.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="mr-4 mt-1">
                <CheckCircle className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Improve Communication</h3>
                <p className="text-gray-600">
                  Keep everyone on the same page with clear schedules and requirements, reducing confusion and missed shifts.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="mr-4 mt-1">
                <CheckCircle className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Adaptable to Your Needs</h3>
                <p className="text-gray-600">
                  Customize worker types and shift requirements to match your unique business needs and organizational structure.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Workforce Management?</h2>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Join thousands of businesses that have streamlined their scheduling and workforce management with StaffSync.
          </p>
          <Button 
            size="lg" 
            className="bg-white text-blue-600 hover:bg-blue-50"
            onClick={() => setLocation("/login")}
          >
            Get Started Today
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-6 md:mb-0">
              <div className="bg-white p-2 rounded-full mr-2">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <span className="text-xl font-bold">StaffSync</span>
            </div>
            <div className="text-gray-400 text-sm">
              © {new Date().getFullYear()} StaffSync. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}