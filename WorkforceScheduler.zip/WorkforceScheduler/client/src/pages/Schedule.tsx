import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  format, 
  startOfWeek, 
  endOfWeek, 
  startOfMonth,
  endOfMonth,
  eachDayOfInterval, 
  eachWeekOfInterval,
  addMonths,
  addWeeks, 
  subMonths,
  subWeeks, 
  isToday,
  isSameMonth 
} from "date-fns";
import { CalendarDays, Download, ChevronLeft, ChevronRight } from "lucide-react";
import RequirementsModal from "@/components/modals/RequirementsModal";
import { useQuery } from "@tanstack/react-query";
import { Shift, ShiftRequirement } from "@shared/schema";

export default function Schedule() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isRequirementsModalOpen, setIsRequirementsModalOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState("month");
  
  // Date calculations for current view (month or week)
  const isMonthView = view === "month";
  
  const viewStart = isMonthView 
    ? startOfMonth(currentDate) 
    : startOfWeek(currentDate, { weekStartsOn: 0 });
    
  const viewEnd = isMonthView 
    ? endOfMonth(currentDate) 
    : endOfWeek(currentDate, { weekStartsOn: 0 });
  
  // For month view, we need to include days from previous/next months to fill the calendar grid
  const calendarStart = isMonthView 
    ? startOfWeek(viewStart, { weekStartsOn: 0 }) 
    : viewStart;
    
  const calendarEnd = isMonthView 
    ? endOfWeek(viewEnd, { weekStartsOn: 0 }) 
    : viewEnd;
  
  // Generate all days to display
  const daysToDisplay = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  
  // For month view, we organize days into weeks
  const weeksInView = isMonthView 
    ? eachWeekOfInterval(
        { start: calendarStart, end: calendarEnd },
        { weekStartsOn: 0 }
      ).map(weekStart => 
        eachDayOfInterval({
          start: weekStart,
          end: endOfWeek(weekStart, { weekStartsOn: 0 })
        })
      )
    : [daysToDisplay]; // For week view, we just have one row of days
  
  // Fetch shifts
  const { data: shifts = [] } = useQuery<Shift[]>({
    queryKey: ['/api/shifts/range', viewStart.toISOString(), viewEnd.toISOString()],
    queryFn: async () => {
      const response = await fetch(`/api/shifts/range?start=${viewStart.toISOString()}&end=${viewEnd.toISOString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch shifts');
      }
      return response.json();
    }
  });

  // Navigation handlers
  const previous = () => {
    if (isMonthView) {
      setCurrentDate(subMonths(currentDate, 1));
    } else {
      setCurrentDate(subWeeks(currentDate, 1));
    }
  };
  
  const next = () => {
    if (isMonthView) {
      setCurrentDate(addMonths(currentDate, 1));
    } else {
      setCurrentDate(addWeeks(currentDate, 1));
    }
  };
  
  const handleAddRequirements = (date: Date) => {
    setSelectedDate(date);
    setIsRequirementsModalOpen(true);
  };
  
  // Group shifts by date
  const shiftsByDate: Record<string, Shift[]> = {};
  shifts.forEach(shift => {
    const dateStr = typeof shift.date === 'string' 
      ? shift.date 
      : format(shift.date, 'yyyy-MM-dd');
    
    if (!shiftsByDate[dateStr]) {
      shiftsByDate[dateStr] = [];
    }
    
    shiftsByDate[dateStr].push(shift);
  });

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Shifts</h2>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          <Button size="sm" onClick={() => handleAddRequirements(new Date())}>
            <CalendarDays className="h-4 w-4 mr-1" />
            Add Shift
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <Tabs defaultValue="month" value={view} onValueChange={setView}>
              <TabsList>
                <TabsTrigger value="month">Month</TabsTrigger>
                <TabsTrigger value="week">Week</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" onClick={previous}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="text-sm font-medium">
                {isMonthView
                  ? format(viewStart, 'MMMM yyyy')
                  : `${format(viewStart, 'MMM d')} - ${format(viewEnd, 'MMM d, yyyy')}`
                }
              </div>
              <Button variant="ghost" size="icon" onClick={next}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Calendar header with weekday names */}
          <div className="grid grid-cols-7 gap-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center">
                <div className="text-sm font-medium text-gray-500">{day}</div>
              </div>
            ))}
          </div>
          
          {/* Calendar grid with days */}
          <div className="mt-2">
            {weeksInView.map((week, weekIndex) => (
              <div key={weekIndex} className="grid grid-cols-7 gap-2 mb-2">
                {week.map((day, dayIndex) => {
                  const dateStr = format(day, 'yyyy-MM-dd');
                  const dayShifts = shiftsByDate[dateStr] || [];
                  const isCurrentMonth = isMonthView ? isSameMonth(day, currentDate) : true;
                  
                  return (
                    <div 
                      key={dayIndex} 
                      className={`
                        min-h-[80px] border rounded-md p-2 relative
                        ${isToday(day) ? 'border-primary bg-primary/5' : 'border-gray-200'}
                        ${!isCurrentMonth ? 'bg-gray-50' : ''}
                      `}
                    >
                      <div className={`text-right text-sm mb-1 ${!isCurrentMonth ? 'text-gray-400' : ''}`}>
                        {format(day, 'd')}
                      </div>
                      
                      {dayShifts.length > 0 && (
                        <div className="space-y-1">
                          {dayShifts.map((shift) => (
                            <div 
                              key={shift.id} 
                              className="bg-blue-100 text-blue-800 rounded p-1 text-xs cursor-pointer overflow-hidden text-ellipsis whitespace-nowrap"
                              onClick={() => handleAddRequirements(day)}
                              title={`${shift.name} (${shift.startTime} - ${shift.endTime})`}
                            >
                              <div className="font-medium">{shift.name}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full justify-start text-xs text-gray-500 mt-1"
                        onClick={() => handleAddRequirements(day)}
                      >
                        {dayShifts.length > 0 ? '+ Add' : '+ Add shift'}
                      </Button>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Shift Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Upcoming Shifts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {shifts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {isMonthView 
                  ? "No shifts scheduled for this month" 
                  : "No shifts scheduled for this week"
                }
              </div>
            ) : (
              shifts.map(shift => (
                <div key={shift.id} className="border rounded-md p-4">
                  <div className="flex justify-between items-center mb-2">
                    <div className="font-medium">{shift.name}</div>
                    <div className="text-sm text-gray-500">
                      {typeof shift.date === 'string' 
                        ? format(new Date(shift.date), 'MMM d, yyyy') 
                        : format(shift.date, 'MMM d, yyyy')}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Time</div>
                      <div>{shift.startTime} - {shift.endTime}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Location</div>
                      <div>{shift.location}</div>
                    </div>
                  </div>
                  {shift.notes && (
                    <div className="mt-2">
                      <div className="text-sm text-gray-500">Notes</div>
                      <div className="text-sm">{shift.notes}</div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
      
      <RequirementsModal
        isOpen={isRequirementsModalOpen}
        onClose={() => setIsRequirementsModalOpen(false)}
        date={selectedDate}
      />
    </div>
  );
}
