import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { useState } from "react";

export default function Settings() {
  const { data: user } = useQuery<User>({
    queryKey: ['/api/auth/current'],
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    shiftReminders: true,
    availabilityUpdates: false,
    schedulesPublished: true
  });
  
  const handleNotificationChange = (key: string) => {
    setNotificationSettings(prev => ({
      ...prev,
      [key]: !prev[key as keyof typeof prev]
    }));
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Settings</h2>
      
      <Tabs defaultValue="account">
        <div>
          <TabsList className="mb-4">
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>
          
          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>
                  Update your personal information and account settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input id="name" defaultValue={user?.name} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" defaultValue={user?.email} />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input id="username" defaultValue={user?.username} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input id="password" type="password" placeholder="••••••••" />
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Connected Accounts</h3>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <svg className="h-6 w-6 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5.46 8.12l-7.58 3.79c-.37.18-.8-.04-.8-.46V8.77c0-.42.4-.65.76-.5l7.58 3.29c.4.18.4.74 0 .92l-.01-.01z" />
                      </svg>
                      <div>
                        <p className="font-medium">Google</p>
                        <p className="text-sm text-gray-500">
                          {user?.googleId ? 'Connected' : 'Not connected'}
                        </p>
                      </div>
                    </div>
                    <Button variant={user?.googleId ? "outline" : "default"}>
                      {user?.googleId ? 'Disconnect' : 'Connect'}
                    </Button>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline">Cancel</Button>
                  <Button>Save Changes</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>
                  Configure how and when you want to be notified
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Email Notifications</h4>
                      <p className="text-sm text-gray-500">
                        Receive emails for important updates
                      </p>
                    </div>
                    <Switch 
                      checked={notificationSettings.emailNotifications}
                      onCheckedChange={() => handleNotificationChange('emailNotifications')}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Shift Reminders</h4>
                      <p className="text-sm text-gray-500">
                        Get notified about upcoming shifts
                      </p>
                    </div>
                    <Switch 
                      checked={notificationSettings.shiftReminders}
                      onCheckedChange={() => handleNotificationChange('shiftReminders')}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Availability Updates</h4>
                      <p className="text-sm text-gray-500">
                        Notifications when workers update their availability
                      </p>
                    </div>
                    <Switch 
                      checked={notificationSettings.availabilityUpdates}
                      onCheckedChange={() => handleNotificationChange('availabilityUpdates')}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Schedules Published</h4>
                      <p className="text-sm text-gray-500">
                        Get notified when new schedules are published
                      </p>
                    </div>
                    <Switch 
                      checked={notificationSettings.schedulesPublished}
                      onCheckedChange={() => handleNotificationChange('schedulesPublished')}
                    />
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline">Cancel</Button>
                  <Button>Save Changes</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="export">
            <Card>
              <CardHeader>
                <CardTitle>Export Data</CardTitle>
                <CardDescription>
                  Export your schedule and worker data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h4 className="font-medium mb-2">Schedule Export</h4>
                    <p className="text-sm text-gray-500 mb-4">
                      Export your current schedule to Excel
                    </p>
                    <Button>
                      <Download className="h-4 w-4 mr-2" />
                      Export Schedule
                    </Button>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h4 className="font-medium mb-2">Worker Data</h4>
                    <p className="text-sm text-gray-500 mb-4">
                      Export your worker database to Excel
                    </p>
                    <Button>
                      <Download className="h-4 w-4 mr-2" />
                      Export Workers
                    </Button>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h4 className="font-medium mb-2">Availability Export</h4>
                    <p className="text-sm text-gray-500 mb-4">
                      Export worker availability data to Excel
                    </p>
                    <Button>
                      <Download className="h-4 w-4 mr-2" />
                      Export Availability
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
