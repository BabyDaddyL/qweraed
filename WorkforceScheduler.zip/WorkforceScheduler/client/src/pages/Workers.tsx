import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Worker, WorkerType } from "@shared/schema";
import { Search, Plus, Edit, Trash, UserPlus, Tags, Palette } from "lucide-react";

export default function Workers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddWorkerOpen, setIsAddWorkerOpen] = useState(false);
  const [isAddTypeOpen, setIsAddTypeOpen] = useState(false);
  const [isEditTypeOpen, setIsEditTypeOpen] = useState(false);
  const [isDeleteTypeOpen, setIsDeleteTypeOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("workers");
  const [newWorker, setNewWorker] = useState({
    name: "",
    email: "",
    phone: "",
    type: "general",
  });
  const [newWorkerType, setNewWorkerType] = useState({
    name: "",
    description: "",
    color: "#3b82f6" // Default blue color
  });
  const [selectedType, setSelectedType] = useState<WorkerType | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch workers
  const { data: workers = [], isLoading: workersLoading } = useQuery<Worker[]>({
    queryKey: ['/api/workers'],
  });
  
  // Fetch worker types
  const { data: workerTypes = [], isLoading: typesLoading } = useQuery<WorkerType[]>({
    queryKey: ['/api/worker-types'],
  });
  
  // Create worker mutation
  const createWorkerMutation = useMutation({
    mutationFn: async (workerData: any) => {
      if (!currentUser) {
        throw new Error("You must be logged in to create workers");
      }
      const response = await apiRequest("POST", "/api/workers", workerData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/workers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Worker added",
        description: "The worker has been added successfully",
      });
      
      setIsAddWorkerOpen(false);
      setNewWorker({
        name: "",
        email: "",
        phone: "",
        type: "general",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add worker",
        variant: "destructive",
      });
    },
  });
  
  // Get current user to ensure we have authentication
  const { data: currentUser } = useQuery({
    queryKey: ["/api/auth/current"],
  });
  
  // Create worker type mutation
  const createWorkerTypeMutation = useMutation({
    mutationFn: async (typeData: any) => {
      if (!currentUser) {
        throw new Error("You must be logged in to create worker types");
      }
      const response = await apiRequest("POST", "/api/worker-types", typeData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/worker-types'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Worker type added",
        description: "The worker type has been added successfully",
      });
      
      setIsAddTypeOpen(false);
      setNewWorkerType({
        name: "",
        description: "",
        color: "#3b82f6"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add worker type",
        variant: "destructive",
      });
    },
  });
  
  // Update worker type mutation
  const updateWorkerTypeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      if (!currentUser) {
        throw new Error("You must be logged in to update worker types");
      }
      const response = await apiRequest("PATCH", `/api/worker-types/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/worker-types'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Worker type updated",
        description: "The worker type has been updated successfully",
      });
      
      setIsEditTypeOpen(false);
      setSelectedType(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update worker type",
        variant: "destructive",
      });
    },
  });
  
  // Delete worker type mutation
  const deleteWorkerTypeMutation = useMutation({
    mutationFn: async (id: number) => {
      if (!currentUser) {
        throw new Error("You must be logged in to delete worker types");
      }
      await apiRequest("DELETE", `/api/worker-types/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/worker-types'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Worker type deleted",
        description: "The worker type has been deleted successfully",
      });
      
      setIsDeleteTypeOpen(false);
      setSelectedType(null);
    },
    onError: (error: any) => {
      // Special handling for the case where the worker type is in use
      if (error.status === 400) {
        toast({
          title: "Cannot delete",
          description: "This worker type is being used by one or more workers. Please reassign those workers before deleting.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to delete worker type",
          variant: "destructive",
        });
      }
      setIsDeleteTypeOpen(false);
    },
  });
  
  const handleAddWorker = () => {
    if (!newWorker.name) {
      toast({
        title: "Error",
        description: "Worker name is required",
        variant: "destructive",
      });
      return;
    }
    
    createWorkerMutation.mutate(newWorker);
  };
  
  const handleAddWorkerType = () => {
    if (!newWorkerType.name) {
      toast({
        title: "Error",
        description: "Worker type name is required",
        variant: "destructive",
      });
      return;
    }
    
    createWorkerTypeMutation.mutate(newWorkerType);
  };
  
  const handleEditWorkerType = () => {
    if (!selectedType || !selectedType.name) {
      toast({
        title: "Error",
        description: "Worker type name is required",
        variant: "destructive",
      });
      return;
    }
    
    updateWorkerTypeMutation.mutate({ 
      id: selectedType.id, 
      data: {
        name: selectedType.name,
        description: selectedType.description || "",
        color: selectedType.color
      }
    });
  };
  
  const handleDeleteWorkerType = () => {
    if (!selectedType) return;
    deleteWorkerTypeMutation.mutate(selectedType.id);
  };
  
  const openEditTypeDialog = (type: WorkerType) => {
    setSelectedType(type);
    setIsEditTypeOpen(true);
  };
  
  const openDeleteTypeDialog = (type: WorkerType) => {
    setSelectedType(type);
    setIsDeleteTypeOpen(true);
  };
  
  const filteredWorkers = searchTerm
    ? workers.filter(worker =>
        worker.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        worker.email?.toLowerCase().includes(searchTerm.toLowerCase()))
    : workers;
  
  // Get a worker type by name
  const getWorkerTypeByName = (name: string) => {
    return workerTypes.find(type => type.name.toLowerCase() === name.toLowerCase());
  };
  
  // Get color for worker type
  const getWorkerTypeColor = (typeName: string) => {
    const foundType = getWorkerTypeByName(typeName);
    return foundType?.color || "#3b82f6"; // Default blue if not found
  };
    
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Workforce Management</h2>
        {activeTab === "workers" ? (
          <Button onClick={() => setIsAddWorkerOpen(true)}>
            <UserPlus className="h-4 w-4 mr-2" />
            Add Worker
          </Button>
        ) : (
          <Button onClick={() => setIsAddTypeOpen(true)}>
            <Tags className="h-4 w-4 mr-2" />
            Add Worker Type
          </Button>
        )}
      </div>
      
      <Tabs defaultValue="workers" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="workers">Workers</TabsTrigger>
          <TabsTrigger value="types">Worker Types</TabsTrigger>
        </TabsList>
        
        <TabsContent value="workers">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Worker Management</CardTitle>
              <CardDescription>
                Manage your workforce and assign worker types
              </CardDescription>
              <div className="flex items-center mt-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Search workers..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {workersLoading ? (
                <div className="text-center py-10">
                  <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-sm text-gray-500">Loading workers...</p>
                </div>
              ) : filteredWorkers.length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  {searchTerm ? "No workers found matching your search" : "No workers added yet"}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredWorkers.map((worker) => {
                      const typeColor = getWorkerTypeColor(worker.type);
                      return (
                        <TableRow key={worker.id}>
                          <TableCell className="font-medium">{worker.name}</TableCell>
                          <TableCell>{worker.email || "-"}</TableCell>
                          <TableCell>{worker.phone || "-"}</TableCell>
                          <TableCell>
                            <span className="px-2 py-1 rounded-full text-xs font-medium"
                                  style={{ 
                                    backgroundColor: `${typeColor}20`, 
                                    color: typeColor
                                  }}>
                              {worker.type.charAt(0).toUpperCase() + worker.type.slice(1)}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Trash className="h-4 w-4 text-destructive" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="types">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Worker Types</CardTitle>
              <CardDescription>
                Define different types of workers and their characteristics
              </CardDescription>
            </CardHeader>
            <CardContent>
              {typesLoading ? (
                <div className="text-center py-10">
                  <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-sm text-gray-500">Loading worker types...</p>
                </div>
              ) : workerTypes.length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  No worker types defined yet
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {workerTypes.map((type) => (
                    <Card key={type.id} className="overflow-hidden">
                      <div 
                        className="h-2" 
                        style={{ backgroundColor: type.color || "#3b82f6" }}
                      ></div>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-lg font-semibold">{type.name}</h3>
                            <p className="text-sm text-gray-500 mt-1">{type.description || "No description"}</p>
                          </div>
                          <div className="flex space-x-1">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => openEditTypeDialog(type)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => openDeleteTypeDialog(type)}
                            >
                              <Trash className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-3 flex items-center">
                          <div 
                            className="w-4 h-4 rounded-full mr-2" 
                            style={{ backgroundColor: type.color || "#3b82f6" }}
                          ></div>
                          <span className="text-xs font-medium">{type.color || "#3b82f6"}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Add Worker Dialog */}
      <Dialog open={isAddWorkerOpen} onOpenChange={setIsAddWorkerOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Worker</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="worker-name">Name</Label>
              <Input
                id="worker-name"
                value={newWorker.name}
                onChange={(e) => setNewWorker({...newWorker, name: e.target.value})}
                placeholder="John Doe"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="worker-email">Email</Label>
              <Input
                id="worker-email"
                type="email"
                value={newWorker.email}
                onChange={(e) => setNewWorker({...newWorker, email: e.target.value})}
                placeholder="john.doe@example.com"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="worker-phone">Phone</Label>
              <Input
                id="worker-phone"
                value={newWorker.phone}
                onChange={(e) => setNewWorker({...newWorker, phone: e.target.value})}
                placeholder="+1 (123) 456-7890"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="worker-type">Worker Type</Label>
              <Select 
                value={newWorker.type} 
                onValueChange={(value) => setNewWorker({...newWorker, type: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select worker type" />
                </SelectTrigger>
                <SelectContent>
                  {workerTypes.map((type) => (
                    <SelectItem key={type.id} value={type.name.toLowerCase()}>
                      <div className="flex items-center">
                        <div 
                          className="w-3 h-3 rounded-full mr-2" 
                          style={{ backgroundColor: type.color || "#3b82f6" }}
                        ></div>
                        {type.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddWorkerOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddWorker} disabled={createWorkerMutation.isPending}>
              Add Worker
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Add Worker Type Dialog */}
      <Dialog open={isAddTypeOpen} onOpenChange={setIsAddTypeOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Worker Type</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="type-name">Type Name</Label>
              <Input
                id="type-name"
                value={newWorkerType.name}
                onChange={(e) => setNewWorkerType({...newWorkerType, name: e.target.value})}
                placeholder="Technician"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type-description">Description</Label>
              <Input
                id="type-description"
                value={newWorkerType.description}
                onChange={(e) => setNewWorkerType({...newWorkerType, description: e.target.value})}
                placeholder="Technical staff for equipment maintenance"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type-color">Color</Label>
              <div className="flex space-x-2">
                <Input
                  id="type-color"
                  type="color"
                  value={newWorkerType.color}
                  onChange={(e) => setNewWorkerType({...newWorkerType, color: e.target.value})}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={newWorkerType.color}
                  onChange={(e) => setNewWorkerType({...newWorkerType, color: e.target.value})}
                  placeholder="#3b82f6"
                  className="flex-1"
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddTypeOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddWorkerType} 
              disabled={createWorkerTypeMutation.isPending}
            >
              Add Worker Type
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Worker Type Dialog */}
      <Dialog open={isEditTypeOpen} onOpenChange={setIsEditTypeOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Worker Type</DialogTitle>
          </DialogHeader>
          
          {selectedType && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-type-name">Type Name</Label>
                <Input
                  id="edit-type-name"
                  value={selectedType.name}
                  onChange={(e) => setSelectedType({...selectedType, name: e.target.value})}
                  placeholder="Technician"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-type-description">Description</Label>
                <Input
                  id="edit-type-description"
                  value={selectedType.description || ""}
                  onChange={(e) => setSelectedType({...selectedType, description: e.target.value})}
                  placeholder="Technical staff for equipment maintenance"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-type-color">Color</Label>
                <div className="flex space-x-2">
                  <Input
                    id="edit-type-color"
                    type="color"
                    value={selectedType.color || "#3b82f6"}
                    onChange={(e) => setSelectedType({...selectedType, color: e.target.value})}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={selectedType.color || "#3b82f6"}
                    onChange={(e) => setSelectedType({...selectedType, color: e.target.value})}
                    placeholder="#3b82f6"
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditTypeOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleEditWorkerType} 
              disabled={updateWorkerTypeMutation.isPending}
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Worker Type Alert Dialog */}
      <AlertDialog open={isDeleteTypeOpen} onOpenChange={setIsDeleteTypeOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the worker type 
              "{selectedType?.name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteWorkerType}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteWorkerTypeMutation.isPending}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
