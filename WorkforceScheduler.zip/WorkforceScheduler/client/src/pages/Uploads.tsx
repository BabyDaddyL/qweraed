import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useQuery } from "@tanstack/react-query";
import { generateTemplateExcel } from "@/lib/excel";
import { useToast } from "@/hooks/use-toast";
import { Activity } from "@shared/schema";
import { format } from "date-fns";
import { Upload, Download, FileText, CalendarDays } from "lucide-react";
import UploadModal from "@/components/modals/UploadModal";

export default function Uploads() {
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const { toast } = useToast();
  
  const { data: activities = [], isLoading } = useQuery<Activity[]>({
    queryKey: ['/api/activities'],
  });
  
  // Filter only upload activities
  const uploadActivities = activities.filter(
    activity => activity.activityType === 'upload'
  );
  
  const downloadTemplate = () => {
    const blob = generateTemplateExcel();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'worker_availability_template.xlsx';
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    document.body.removeChild(a);
    
    toast({
      title: "Template downloaded",
      description: "Fill in the template and upload it back",
    });
  };
  
  const getFileIcon = (description: string) => {
    if (description.toLowerCase().includes('availability')) {
      return <CalendarDays className="h-4 w-4 text-blue-500" />;
    }
    return <FileText className="h-4 w-4 text-gray-500" />;
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">File Uploads</h2>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={downloadTemplate}>
            <Download className="h-4 w-4 mr-2" />
            Download Template
          </Button>
          <Button onClick={() => setIsUploadModalOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Upload File
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Upload History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-10">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-sm text-gray-500">Loading upload history...</p>
            </div>
          ) : uploadActivities.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              No files have been uploaded yet
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>File Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {uploadActivities.map((activity) => (
                  <TableRow key={activity.id}>
                    <TableCell>
                      <div className="flex items-center">
                        {getFileIcon(activity.description)}
                        <span className="ml-2">
                          {activity.description.includes('availability') 
                            ? 'Worker Availability' 
                            : 'File Upload'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>{activity.description}</TableCell>
                    <TableCell>
                      {typeof activity.timestamp === 'string'
                        ? format(new Date(activity.timestamp), 'MMM d, yyyy \'at\' h:mm a')
                        : format(activity.timestamp, 'MMM d, yyyy \'at\' h:mm a')}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        <Download className="h-3 w-3 mr-1" />
                        Download
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      
      <UploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)}
      />
    </div>
  );
}
