import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";

interface ActionCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  buttonText: string;
  onClick: () => void;
}

export default function ActionCard({ 
  title, 
  description, 
  icon: Icon, 
  buttonText, 
  onClick 
}: ActionCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-primary font-medium">{title}</h4>
          <Icon className="h-5 w-5 text-primary" />
        </div>
        <p className="text-gray-600 text-sm mb-4">{description}</p>
        <Button 
          className="w-full"
          onClick={onClick}
        >
          {buttonText}
        </Button>
      </CardContent>
    </Card>
  );
}
