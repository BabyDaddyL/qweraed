import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ChevronLeft, 
  ChevronRight,
} from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, addMonths, subMonths, isSameMonth, isSameDay, parseISO } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { Shift } from "@shared/schema";

interface CalendarProps {
  onDateClick: (date: Date) => void;
}

export default function Calendar({ onDateClick }: CalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [calendarView, setCalendarView] = useState<"weekly" | "monthly">("monthly");
  
  // Get all shifts for the current month
  const startDate = startOfMonth(currentMonth);
  const endDate = endOfMonth(currentMonth);
  
  const { data: shifts = [] } = useQuery<Shift[]>({
    queryKey: ['/api/shifts/range', startDate.toISOString(), endDate.toISOString()],
    queryFn: async () => {
      const response = await fetch(`/api/shifts/range?start=${startDate.toISOString()}&end=${endDate.toISOString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch shifts');
      }
      const data = await response.json();
      console.log('Calendar shifts data:', data);
      return data;
    }
  });

  const days = eachDayOfInterval({
    start: startDate,
    end: endDate
  });
  
  // Get days from previous month to fill the calendar grid
  const firstDayOfMonth = startOfMonth(currentMonth).getDay();
  const prevMonthDays = firstDayOfMonth > 0 ? firstDayOfMonth : 0;
  
  // Get days from next month to fill the calendar grid
  const lastDayOfMonth = endOfMonth(currentMonth).getDay();
  const nextMonthDays = lastDayOfMonth < 6 ? 6 - lastDayOfMonth : 0;
  
  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };
  
  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };
  
  const goToToday = () => {
    setCurrentMonth(new Date());
  };
  
  // Count shifts per day
  const getShiftsForDay = (date: Date) => {
    if (!shifts || shifts.length === 0) {
      return [];
    }
    
    return shifts.filter(shift => {
      try {
        // All shift dates should be strings in the database
        // But we'll handle other cases just in case
        const shiftDateStr = typeof shift.date === 'string' 
          ? shift.date 
          : String(shift.date);
        
        // Remove any time component if it exists
        const dateStr = shiftDateStr.split('T')[0];
        const shiftDate = parseISO(dateStr);
        
        return isSameDay(shiftDate, date);
      } catch (err) {
        console.error('Error parsing date:', shift.date, err);
        return false;
      }
    });
  };

  return (
    <Card className="shadow-sm">
      <CardHeader className="p-4 flex-row items-center justify-between border-b">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={prevMonth}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <CardTitle className="text-base font-medium">
            {format(currentMonth, 'MMMM yyyy')}
          </CardTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={nextMonth}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center">
          <Button
            variant={calendarView === "weekly" ? "default" : "outline"}
            size="sm"
            className="text-xs mr-1"
            onClick={() => setCalendarView("weekly")}
          >
            Weekly
          </Button>
          <Button
            variant={calendarView === "monthly" ? "default" : "outline"}
            size="sm"
            className="text-xs"
            onClick={() => setCalendarView("monthly")}
          >
            Monthly
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="ml-2 text-xs text-primary"
            onClick={goToToday}
          >
            Today
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {/* Weekday header */}
        <div className="grid grid-cols-7 text-center border-b">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => (
            <div key={i} className="py-2 text-sm font-medium text-gray-500">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7 text-sm">
          {/* Previous month days */}
          {Array.from({ length: prevMonthDays }).map((_, index) => {
            const date = new Date(currentMonth);
            date.setDate(index - prevMonthDays + 1);
            return (
              <div 
                key={`prev-${index}`} 
                className="border p-1 text-gray-400"
              >
                <div className="p-1">{date.getDate()}</div>
              </div>
            );
          })}
          
          {/* Current month days */}
          {days.map((day, index) => {
            const shiftsForDay = getShiftsForDay(day);
            const shiftsCount = shiftsForDay.length;
            
            // Get a color for a shift based on its name, location, etc.
            const getShiftColor = (shift: Shift) => {
              // Simple hash function to generate a consistent color
              const str = shift.name + (shift.location || '');
              let hash = 0;
              for (let i = 0; i < str.length; i++) {
                hash = ((hash << 5) - hash) + str.charCodeAt(i);
                hash = hash & hash; // Convert to 32bit integer
              }
              
              // Use a set of predefined colors
              const colors = [
                "bg-blue-100 text-blue-800",
                "bg-green-100 text-green-800",
                "bg-purple-100 text-purple-800",
                "bg-amber-100 text-amber-800",
                "bg-pink-100 text-pink-800",
                "bg-indigo-100 text-indigo-800",
                "bg-cyan-100 text-cyan-800"
              ];
              
              return colors[Math.abs(hash) % colors.length];
            };
            
            return (
              <div 
                key={`current-${index}`} 
                className={`border p-1 hover:bg-gray-50 cursor-pointer ${
                  isSameDay(day, new Date()) ? 'bg-blue-50' : ''
                }`}
                onClick={() => onDateClick(day)}
              >
                <div className="p-1 font-medium">
                  {format(day, 'd')}
                </div>
                
                <div className="mt-1 space-y-1">
                  {shiftsForDay.slice(0, 2).map((shift) => (
                    <div 
                      key={shift.id} 
                      className={`text-xs p-1 rounded flex items-center justify-between ${getShiftColor(shift)}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onDateClick(day);
                      }}
                    >
                      <span className="font-medium truncate">
                        {shift.name}
                      </span>
                      <span className="text-xs opacity-80 whitespace-nowrap ml-1">
                        {shift.startTime.substring(0, 5)}
                      </span>
                    </div>
                  ))}
                  {shiftsCount > 2 && (
                    <div className="text-xs text-blue-600 font-medium">
                      +{shiftsCount - 2} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          
          {/* Next month days */}
          {Array.from({ length: nextMonthDays }).map((_, index) => {
            const date = new Date(currentMonth);
            date.setDate(endOfMonth(currentMonth).getDate() + index + 1);
            return (
              <div 
                key={`next-${index}`} 
                className="border p-1 text-gray-400"
              >
                <div className="p-1">{date.getDate()}</div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
