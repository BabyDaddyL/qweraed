import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";
import { format } from "date-fns";
import { Upload, Edit, CalendarCheck, FileText } from "lucide-react";

export default function ActivityList() {
  const { data: activities = [], isLoading } = useQuery<Activity[]>({
    queryKey: ['/api/activities'],
  });

  const getIcon = (activityType: string) => {
    switch (activityType) {
      case 'upload':
        return <Upload className="h-5 w-5 text-primary" />;
      case 'edit':
        return <Edit className="h-5 w-5 text-accent" />;
      case 'publish':
        return <CalendarCheck className="h-5 w-5 text-secondary" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const formatDate = (date: string | Date) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return format(dateObj, 'MMM d, yyyy \'at\' h:mm a');
  };

  return (
    <Card className="shadow-sm">
      <CardHeader className="p-4 border-b">
        <CardTitle className="text-base font-medium">Activity History</CardTitle>
      </CardHeader>
      <CardContent className="p-0 divide-y">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            <p className="mt-2 text-sm text-gray-500">Loading activities...</p>
          </div>
        ) : activities.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm text-gray-500">No recent activities</p>
          </div>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="p-4 flex items-start">
              {getIcon(activity.activityType)}
              <div className="ml-3">
                <p className="text-sm font-medium">{activity.description}</p>
                <p className="text-xs text-gray-500">{formatDate(activity.timestamp)}</p>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
