import { Button } from "@/components/ui/button";
import { Bell, HelpCircle, Menu } from "lucide-react";

interface HeaderProps {
  onOpenSidebar: () => void;
  title: string;
}

export default function Header({ onOpenSidebar, title }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm z-10 sticky top-0">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden mr-4"
            onClick={onOpenSidebar}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h2 className="text-xl font-semibold text-gray-800">{title}</h2>
        </div>
        
        <div className="flex items-center">
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="ml-2">
            <HelpCircle className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}
