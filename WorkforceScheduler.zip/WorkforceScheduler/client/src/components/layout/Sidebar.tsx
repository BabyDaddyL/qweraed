import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  CalendarDays, 
  ChevronLeft, 
  LogOut, 
  Settings, 
  Upload, 
  Users,
  LayoutDashboard
} from "lucide-react";
import { User } from "@shared/schema";
import { logout } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
}

export default function Sidebar({ isOpen, onClose, user }: SidebarProps) {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  
  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account"
      });
      // Explicitly navigate to landing page
      navigate("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={onClose}
        />
      )}
      
      <aside 
        className={`
          bg-white shadow-md z-30 w-64 fixed h-full lg:relative transition-all duration-300 transform
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white">
              <Users className="h-5 w-5" />
            </div>
            <h1 className="ml-3 text-xl font-bold text-gray-800">StaffSync</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={onClose}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
        </div>
        
        <nav className="mt-4">
          <ul>
            <SidebarItem 
              href="/dashboard"
              icon={<LayoutDashboard className="h-5 w-5" />}
              text="Dashboard"
              isActive={location === "/" || location === "/dashboard"}
            />
            <SidebarItem 
              href="/schedule"
              icon={<CalendarDays className="h-5 w-5" />}
              text="Shifts"
              isActive={location === "/schedule"}
            />
            <SidebarItem 
              href="/workers"
              icon={<Users className="h-5 w-5" />}
              text="Workers"
              isActive={location === "/workers"}
            />
            <SidebarItem 
              href="/uploads"
              icon={<Upload className="h-5 w-5" />}
              text="Uploads"
              isActive={location === "/uploads"}
            />
            <SidebarItem 
              href="/settings"
              icon={<Settings className="h-5 w-5" />}
              text="Settings"
              isActive={location === "/settings"}
            />
          </ul>
        </nav>
        
        <div className="absolute bottom-0 w-full p-4 border-t">
          <div className="flex items-center">
            <Avatar>
              <AvatarImage src={user?.avatar || ""} alt={user?.name || "User"} />
              <AvatarFallback>{user?.name ? getInitials(user.name) : "U"}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-800">{user?.name || "User"}</p>
              <p className="text-xs text-gray-500">{user?.email || "No email"}</p>
            </div>
          </div>
          <Button
            variant="outline"
            className="mt-4 w-full flex items-center justify-center text-sm"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </aside>
    </>
  );
}

interface SidebarItemProps {
  href: string;
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
}

function SidebarItem({ href, icon, text, isActive }: SidebarItemProps) {
  return (
    <li className="px-4 py-2">
      <Link href={href}>
        <div className={`
          flex items-center transition-colors cursor-pointer
          ${isActive ? 'text-primary font-medium' : 'text-gray-700 hover:text-primary'}
        `}>
          <span className="mr-3">{icon}</span>
          {text}
        </div>
      </Link>
    </li>
  );
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
}
