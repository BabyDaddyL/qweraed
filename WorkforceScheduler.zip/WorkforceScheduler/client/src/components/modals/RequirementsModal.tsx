import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { 
  MinusCircle, 
  PlusCircle, 
  Construction, 
  Users, 
  UserCog,
  Plus,
  Tags,
  Edit,
  Palette,
  AlertCircle,
  Trash2,
  X
} from "lucide-react";
import { format } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { WorkerType } from "@shared/schema";

interface RequirementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: Date;
}

interface WorkerRequirement {
  type: string;
  count: number;
  label: string;
  description: string;
  icon: React.ReactNode;
  color?: string;
}

export default function RequirementsModal({ isOpen, onClose, date }: RequirementsModalProps) {
  const [shiftName, setShiftName] = useState("Morning Shift");
  const [location, setLocation] = useState("Main Building");
  const [startTime, setStartTime] = useState("08:00");
  const [endTime, setEndTime] = useState("16:00");
  const [notes, setNotes] = useState("");
  const [isAddWorkerTypeOpen, setIsAddWorkerTypeOpen] = useState(false);
  const [selectedShiftId, setSelectedShiftId] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [shiftToDelete, setShiftToDelete] = useState<number | null>(null);
  const [newWorkerType, setNewWorkerType] = useState({
    name: "",
    description: "",
    color: "#3b82f6" // Default blue color
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch worker types
  const { data: workerTypes = [], isLoading: isLoadingWorkerTypes } = useQuery<WorkerType[]>({
    queryKey: ['/api/worker-types'],
  });
  
  // Get current user to ensure we have authentication
  const { data: currentUser } = useQuery({
    queryKey: ["/api/auth/current"],
  });
  
  // Fetch existing shifts for the selected date
  const formattedDate = format(date, 'yyyy-MM-dd');
  const { data: existingShifts = [] } = useQuery({
    queryKey: ['/api/shifts/range', formattedDate, formattedDate],
    queryFn: async () => {
      const response = await fetch(`/api/shifts/range?start=${formattedDate}T00:00:00Z&end=${formattedDate}T23:59:59Z`);
      if (!response.ok) {
        throw new Error('Failed to fetch shifts');
      }
      console.log('Fetched shifts for date:', formattedDate);
      return response.json();
    },
    enabled: isOpen // Only run this query when the modal is open
  });
  
  // Get the currently selected shift or the first shift as fallback
  const firstShift = existingShifts.length > 0 ? existingShifts[0] : null;
  const shiftId = selectedShiftId || firstShift?.id;

  // Fetch requirements for the selected shift
  const { data: shiftRequirements = [] } = useQuery({
    queryKey: ['/api/requirements', shiftId],
    queryFn: async () => {
      const response = await fetch(`/api/requirements/${shiftId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch shift requirements');
      }
      console.log('Fetched requirements for shift:', shiftId);
      return response.json();
    },
    enabled: !!shiftId // Only run this query if we have a shift ID
  });

  // Create worker type mutation
  const createWorkerTypeMutation = useMutation({
    mutationFn: async (typeData: any) => {
      if (!currentUser) {
        throw new Error("You must be logged in to create worker types");
      }
      const response = await apiRequest("POST", "/api/worker-types", typeData);
      return response.json();
    },
    onSuccess: (newType) => {
      queryClient.invalidateQueries({ queryKey: ['/api/worker-types'] });
      
      // Add the new worker type to the requirements
      const newRequirement: WorkerRequirement = {
        type: newType.name.toLowerCase(),
        count: 1,
        label: newType.name,
        description: newType.description || `Workers with ${newType.name.toLowerCase()} responsibilities`,
        icon: <Users className="h-5 w-5" style={{ color: newType.color || "#3b82f6" }} />,
        color: newType.color
      };
      
      setWorkerRequirements(prev => [...prev, newRequirement]);
      
      // Reset and close dialog
      setNewWorkerType({
        name: "",
        description: "",
        color: "#3b82f6"
      });
      setIsAddWorkerTypeOpen(false);
      
      toast({
        title: "Worker type added",
        description: `${newType.name} has been added to the requirements`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add worker type",
        variant: "destructive",
      });
    }
  });

  // Initialize worker requirements from worker types when they load
  useEffect(() => {
    if (!isOpen || !workerTypes.length) return;
    
    // Convert worker types to requirements
    const requirements: WorkerRequirement[] = workerTypes.map(type => ({
      type: type.name.toLowerCase(),
      count: 0, // Start with 0 as default
      label: type.name,
      description: type.description || `Workers with ${type.name.toLowerCase()} responsibilities`,
      icon: <Users className="h-5 w-5" style={{ color: type.color || "#3b82f6" }} />,
      color: type.color
    }));
    
    // Only process if we have requirements
    if (requirements.length > 0) {
      // Check if we have existing shift data to populate
      if (shiftRequirements?.length > 0) {
        // If we have existing requirements, use those values
        console.log('Using existing shift requirements:', shiftRequirements);
        
        const mappedReqs = requirements.map(req => {
          // Find any existing requirement for this worker type
          const existingReq = shiftRequirements.find(
            (r: any) => r.workerType.toLowerCase() === req.type.toLowerCase()
          );
          
          return {
            ...req,
            count: existingReq ? existingReq.count : 0
          };
        });
        
        setWorkerRequirements(mappedReqs);
        
        // Find the currently selected shift
        const currentShift = selectedShiftId 
          ? existingShifts.find((s: any) => s.id === selectedShiftId)
          : firstShift;
          
        if (currentShift) {
          // Also set other shift details
          setShiftName(currentShift.name);
          setLocation(currentShift.location || 'Main Building');
          setStartTime(currentShift.startTime);
          setEndTime(currentShift.endTime);
          setNotes(currentShift.notes || '');
        }
      } else {
        // Otherwise set default values
        const defaultReqs = requirements.map((req, index) => ({
          ...req,
          count: index === 0 ? 2 : (index === 1 ? 1 : 0) // First type gets 2, second gets 1, rest get 0
        }));
        setWorkerRequirements(defaultReqs);
      }
    }
  }, [isOpen, workerTypes.length, shiftRequirements?.length, firstShift?.id, selectedShiftId, existingShifts]);

  // Initialize with some default requirements if we don't have worker types
  const [workerRequirements, setWorkerRequirements] = useState<WorkerRequirement[]>([
    {
      type: "general",
      count: 4,
      label: "General Workers",
      description: "Workers who can perform general tasks",
      icon: <Users className="h-5 w-5 text-blue-600" />,
      color: "#2563eb"
    },
    {
      type: "specialized",
      count: 2,
      label: "Specialized Workers",
      description: "Workers with specialized skills or certifications",
      icon: <Construction className="h-5 w-5 text-purple-600" />,
      color: "#9333ea"
    },
    {
      type: "supervisor",
      count: 1,
      label: "Supervisors",
      description: "Team leaders or supervisory staff",
      icon: <UserCog className="h-5 w-5 text-green-600" />,
      color: "#16a34a"
    }
  ]);

  const createShiftMutation = useMutation({
    mutationFn: async (shiftData: any) => {
      if (!currentUser) {
        throw new Error("You must be logged in to create shifts");
      }
      const response = await apiRequest("POST", "/api/shifts", shiftData);
      return response.json();
    },
    onSuccess: (shift) => {
      // After creating the shift, create requirements for each worker type
      workerRequirements.forEach(req => {
        if (req.count > 0) {
          createRequirementMutation.mutate({
            shiftId: shift.id,
            workerType: req.type,
            count: req.count
          });
        }
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/shifts/range'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Shift saved",
        description: "Shift and worker requirements have been saved successfully",
      });
      // Reset form
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save shift requirements",
        variant: "destructive",
      });
    }
  });

  const createRequirementMutation = useMutation({
    mutationFn: async (requirementData: any) => {
      if (!currentUser) {
        throw new Error("You must be logged in to create requirements");
      }
      const response = await apiRequest("POST", "/api/requirements", requirementData);
      return response.json();
    }
  });
  
  const handleAddWorkerType = () => {
    if (!newWorkerType.name) {
      toast({
        title: "Error",
        description: "Worker type name is required",
        variant: "destructive",
      });
      return;
    }
    
    createWorkerTypeMutation.mutate(newWorkerType);
  };

  const handleChangeCount = (index: number, increment: boolean) => {
    setWorkerRequirements(prev => 
      prev.map((req, i) => 
        i === index 
          ? { ...req, count: increment ? req.count + 1 : Math.max(0, req.count - 1) }
          : req
      )
    );
  };
  
  const handleRemoveWorkerType = (index: number) => {
    // Set count to 0 instead of removing completely to maintain the worker type
    setWorkerRequirements(prev => 
      prev.map((req, i) => 
        i === index 
          ? { ...req, count: 0 }
          : req
      )
    );
    
    toast({
      title: "Worker requirement updated",
      description: "Worker count has been set to 0",
    });
  };

  // Update shift mutation
  const updateShiftMutation = useMutation({
    mutationFn: async ({ id, shiftData }: { id: number, shiftData: any }) => {
      if (!currentUser) {
        throw new Error("You must be logged in to update shifts");
      }
      const response = await apiRequest("PATCH", `/api/shifts/${id}`, shiftData);
      return response.json();
    },
    onSuccess: (shift) => {
      // Handle requirements updates
      // First, clear existing requirements
      if (shiftRequirements.length > 0) {
        shiftRequirements.forEach((req: any) => {
          // Delete requirement if not needed anymore, otherwise update it
          const newReq = workerRequirements.find(r => 
            r.type.toLowerCase() === req.workerType.toLowerCase()
          );
          
          if (!newReq || newReq.count === 0) {
            // Delete requirement if count is zero
            fetch(`/api/requirements/${req.id}`, {
              method: 'DELETE',
              headers: {
                'Content-Type': 'application/json'
              },
            })
            .then(response => {
              if (!response.ok) {
                throw new Error('Failed to delete requirement');
              }
              console.log('Deleted requirement:', req.id);
            })
            .catch(error => {
              console.error('Error deleting requirement:', error);
            });
          } else if (newReq.count !== req.count) {
            // Update requirement with new count
            fetch(`/api/requirements/${req.id}`, {
              method: 'PATCH',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ count: newReq.count })
            })
            .then(response => {
              if (!response.ok) {
                throw new Error('Failed to update requirement');
              }
              return response.json();
            })
            .then(data => {
              console.log('Updated requirement:', data);
            })
            .catch(error => {
              console.error('Error updating requirement:', error);
            });
          }
        });
      }
      
      // Add any new requirements
      workerRequirements.forEach(req => {
        if (req.count > 0) {
          const existingReq = shiftRequirements.find((r: any) => 
            r.workerType.toLowerCase() === req.type.toLowerCase()
          );
          
          if (!existingReq) {
            // Create new requirement
            createRequirementMutation.mutate({
              shiftId: shift.id,
              workerType: req.type,
              count: req.count
            });
          }
        }
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/shifts/range'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Shift updated",
        description: "Shift and worker requirements have been updated successfully",
      });
      // Reset form
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update shift",
        variant: "destructive",
      });
    }
  });
  
  // Delete shift mutation
  const deleteShiftMutation = useMutation({
    mutationFn: async (id: number) => {
      if (!currentUser) {
        throw new Error("You must be logged in to delete shifts");
      }
      const response = await apiRequest("DELETE", `/api/shifts/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/shifts/range'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      
      toast({
        title: "Shift deleted",
        description: "Shift has been deleted successfully",
      });
      
      // Reset form after deleting
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete shift",
        variant: "destructive",
      });
    }
  });
  
  // Utility function to reset form state
  const resetForm = () => {
    setSelectedShiftId(null);
    setShiftName("Morning Shift");
    setLocation("Main Building");
    setStartTime("08:00");
    setEndTime("16:00");
    setNotes("");
  };
  
  const handleSave = () => {
    if (!shiftName.trim()) {
      toast({
        title: "Error",
        description: "Shift name is required",
        variant: "destructive",
      });
      return;
    }
    
    const shiftData = {
      name: shiftName,
      location,
      date: format(date, 'yyyy-MM-dd'),
      startTime,
      endTime,
      notes: notes || "" // Use empty string if notes is null/undefined
    };
    
    if (selectedShiftId) {
      // Update existing shift
      updateShiftMutation.mutate({ 
        id: selectedShiftId,
        shiftData
      });
    } else {
      // Create new shift
      createShiftMutation.mutate(shiftData);
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
          <button 
            onClick={onClose}
            className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none"
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </button>

          <DialogHeader>
            <DialogTitle>Shifts for {format(date, 'MMMM d, yyyy')}</DialogTitle>
            <DialogDescription>
              View or add shifts for the selected date
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Date: <span className="font-medium">{format(date, 'MMM d, yyyy')}</span>
              </div>
            </div>
            
            {/* Display existing shifts */}
            {existingShifts.length > 0 ? (
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Existing Shifts</h3>
                <div className="divide-y divide-gray-100 rounded-md border">
                  {existingShifts.map((shift: any) => (
                    <div key={shift.id} className="flex items-center justify-between p-3 hover:bg-gray-50">
                      <div className="space-y-1">
                        <h4 className="font-medium">{shift.name}</h4>
                        <div className="flex space-x-4 text-sm text-gray-500">
                          <span>{shift.startTime.substring(0, 5)} - {shift.endTime.substring(0, 5)}</span>
                          <span>•</span>
                          <span>{shift.location}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            // Load this shift details
                            setSelectedShiftId(shift.id);
                            setShiftName(shift.name);
                            setLocation(shift.location || 'Main Building');
                            setStartTime(shift.startTime);
                            setEndTime(shift.endTime);
                            setNotes(shift.notes || '');
                          }}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => {
                            setShiftToDelete(shift.id);
                            setIsDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => resetForm()}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Another Shift
                </Button>
              </div>
            ) : (
              <div className="text-center p-6 border border-dashed rounded-lg">
                <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-50">
                  <AlertCircle className="h-6 w-6 text-blue-500" />
                </div>
                <h3 className="mb-1 text-base font-medium">No shifts scheduled</h3>
                <p className="text-sm text-gray-500 mb-4">
                  There are no shifts scheduled for this date yet.
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => resetForm()}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add First Shift
                </Button>
              </div>
            )}
            
            <div className="border-t pt-4">
              <h3 className="font-medium mb-3">
                {selectedShiftId ? 'Edit Shift' : 'Add New Shift'}
              </h3>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="shift-name">Shift Name</Label>
                <Input 
                  id="shift-name" 
                  value={shiftName} 
                  onChange={(e) => setShiftName(e.target.value)} 
                  placeholder="Morning Shift" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Main Building">Main Building</SelectItem>
                    <SelectItem value="Warehouse">Warehouse</SelectItem>
                    <SelectItem value="Office Complex">Office Complex</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start-time">Start Time</Label>
                <Input 
                  id="start-time" 
                  type="time" 
                  value={startTime} 
                  onChange={(e) => setStartTime(e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end-time">End Time</Label>
                <Input 
                  id="end-time" 
                  type="time" 
                  value={endTime} 
                  onChange={(e) => setEndTime(e.target.value)} 
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea 
                id="notes" 
                placeholder="Any additional information about this shift"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="min-h-[80px]"
              />
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">Worker Requirements</h3>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setIsAddWorkerTypeOpen(true)}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Add Worker Type
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Create a new worker type</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              
              {isLoadingWorkerTypes ? (
                <div className="flex justify-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : workerRequirements.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  No worker types defined. Add a worker type to continue.
                </div>
              ) : (
                workerRequirements.map((req, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg border relative group">
                    <button 
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                      onClick={() => handleRemoveWorkerType(index)}
                    >
                      <X className="h-4 w-4 text-gray-400 hover:text-red-500 transition-colors" />
                    </button>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <div className="w-5 h-5 flex items-center justify-center">
                          {req.icon}
                        </div>
                        <span className="font-medium ml-2">{req.label}</span>
                      </div>
                      <div className="flex items-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleChangeCount(index, false)}
                        >
                          <MinusCircle className="h-5 w-5" />
                        </Button>
                        <span className="w-8 text-center">{req.count}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleChangeCount(index, true)}
                        >
                          <PlusCircle className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600">{req.description}</div>
                  </div>
                ))
              )}
            </div>
          </div>
          
          <DialogFooter className="mt-6">
            <Button 
              onClick={handleSave}
              disabled={
                createShiftMutation.isPending || 
                updateShiftMutation.isPending || 
                workerRequirements.length === 0
              }
              className="w-full"
            >
              {selectedShiftId ? 'Update Shift' : 'Save Shift'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Add Worker Type Dialog */}
      <Dialog open={isAddWorkerTypeOpen} onOpenChange={setIsAddWorkerTypeOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Worker Type</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="type-name">Type Name</Label>
              <Input
                id="type-name"
                value={newWorkerType.name}
                onChange={(e) => setNewWorkerType({...newWorkerType, name: e.target.value})}
                placeholder="Technician"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type-description">Description</Label>
              <Input
                id="type-description"
                value={newWorkerType.description}
                onChange={(e) => setNewWorkerType({...newWorkerType, description: e.target.value})}
                placeholder="Technical staff for equipment maintenance"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type-color">Color</Label>
              <div className="flex space-x-2">
                <Input
                  id="type-color"
                  type="color"
                  value={newWorkerType.color}
                  onChange={(e) => setNewWorkerType({...newWorkerType, color: e.target.value})}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={newWorkerType.color}
                  onChange={(e) => setNewWorkerType({...newWorkerType, color: e.target.value})}
                  placeholder="#3b82f6"
                  className="flex-1"
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddWorkerTypeOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddWorkerType} 
              disabled={createWorkerTypeMutation.isPending}
            >
              Add Worker Type
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the shift
              and all related worker requirements.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => {
                if (shiftToDelete) {
                  deleteShiftMutation.mutate(shiftToDelete);
                  setIsDeleteDialogOpen(false);
                }
              }}
            >
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
