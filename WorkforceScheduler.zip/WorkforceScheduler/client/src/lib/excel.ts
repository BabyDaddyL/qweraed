import * as XLSX from 'xlsx';

export interface WorkerAvailability {
  workerId: number;
  date: Date;
  isAvailable: boolean;
  startTime?: string;
  endTime?: string;
  notes?: string;
}

/**
 * Parse an Excel file containing worker availability data
 * Expected format:
 * - Sheet 1: Worker information (ID, Name)
 * - Sheet 2+: Availability per worker (Date, Available, Start Time, End Time, Notes)
 */
export async function parseWorkerAvailability(file: File): Promise<WorkerAvailability[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) {
          reject(new Error("Failed to read file"));
          return;
        }
        
        const workbook = XLSX.read(data, { type: 'binary' });
        const availabilities: WorkerAvailability[] = [];
        
        // Iterate through sheets (assuming first sheet is worker info)
        const workerSheet = workbook.Sheets[workbook.SheetNames[0]];
        const workers = XLSX.utils.sheet_to_json(workerSheet);
        
        // For each worker, process their availability
        workers.forEach((worker: any) => {
          const workerId = worker.ID || worker.id;
          
          // Look for a sheet with the worker's name
          const workerName = worker.Name || worker.name;
          const sheetName = workbook.SheetNames.find(name => name.includes(workerName));
          
          if (sheetName && workbook.Sheets[sheetName]) {
            const availabilityData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
            
            availabilityData.forEach((avail: any) => {
              // Parse date - could be in various formats, try to handle Excel date format
              let date;
              if (avail.Date instanceof Date) {
                date = avail.Date;
              } else if (typeof avail.Date === 'number') {
                // Excel date number
                date = XLSX.SSF.parse_date_code(avail.Date);
                date = new Date(date.y, date.m - 1, date.d);
              } else {
                // Try to parse as string
                date = new Date(avail.Date);
              }
              
              if (isNaN(date.getTime())) {
                console.warn(`Invalid date format for worker ${workerId}:`, avail.Date);
                return; // Skip this entry
              }
              
              availabilities.push({
                workerId,
                date,
                isAvailable: avail.Available === 'Yes' || avail.Available === true || avail.Available === 1,
                startTime: avail.StartTime || avail['Start Time'],
                endTime: avail.EndTime || avail['End Time'],
                notes: avail.Notes || ''
              });
            });
          }
        });
        
        resolve(availabilities);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = (error) => {
      reject(error);
    };
    
    reader.readAsBinaryString(file);
  });
}

// Mock function to generate a template Excel file that users can download and fill
export function generateTemplateExcel(): Blob {
  const workbook = XLSX.utils.book_new();
  
  // Worker info sheet
  const workerData = [
    { ID: 1, Name: "John Doe", Type: "general" },
    { ID: 2, Name: "Jane Smith", Type: "specialized" },
    { ID: 3, Name: "Mike Johnson", Type: "supervisor" }
  ];
  const workerSheet = XLSX.utils.json_to_sheet(workerData);
  XLSX.utils.book_append_sheet(workbook, workerSheet, "Workers");
  
  // Example availability sheet for one worker
  const availData = [
    { Date: "2023-10-01", Available: "Yes", "Start Time": "09:00", "End Time": "17:00", Notes: "" },
    { Date: "2023-10-02", Available: "Yes", "Start Time": "09:00", "End Time": "17:00", Notes: "" },
    { Date: "2023-10-03", Available: "No", "Start Time": "", "End Time": "", Notes: "Vacation" },
    { Date: "2023-10-04", Available: "Yes", "Start Time": "12:00", "End Time": "20:00", Notes: "" },
    { Date: "2023-10-05", Available: "Yes", "Start Time": "09:00", "End Time": "17:00", Notes: "" }
  ];
  const availSheet = XLSX.utils.json_to_sheet(availData);
  XLSX.utils.book_append_sheet(workbook, availSheet, "John Doe - Availability");
  
  // Create and return blob
  const excelBlob = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  return new Blob([excelBlob], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}

// Export availability to Excel
export function exportAvailabilityToExcel(availabilities: WorkerAvailability[], workerNames: Record<number, string>): Blob {
  const workbook = XLSX.utils.book_new();
  
  // Group availabilities by worker
  const workerAvailabilities: Record<number, WorkerAvailability[]> = {};
  
  availabilities.forEach(avail => {
    if (!workerAvailabilities[avail.workerId]) {
      workerAvailabilities[avail.workerId] = [];
    }
    workerAvailabilities[avail.workerId].push(avail);
  });
  
  // Create a sheet for each worker
  for (const [workerId, workerAvail] of Object.entries(workerAvailabilities)) {
    const workerIdNum = parseInt(workerId);
    const workerName = workerNames[workerIdNum] || `Worker ${workerId}`;
    
    const formattedData = workerAvail.map(avail => ({
      Date: avail.date.toISOString().split('T')[0],
      Available: avail.isAvailable ? "Yes" : "No",
      "Start Time": avail.startTime || "",
      "End Time": avail.endTime || "",
      Notes: avail.notes || ""
    }));
    
    const sheet = XLSX.utils.json_to_sheet(formattedData);
    XLSX.utils.book_append_sheet(workbook, sheet, workerName);
  }
  
  // Create and return blob
  const excelBlob = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  return new Blob([excelBlob], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}
