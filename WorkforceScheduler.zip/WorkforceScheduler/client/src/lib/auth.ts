import { apiRequest } from "./queryClient";
import { queryClient } from "./queryClient";

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface RegisterCredentials extends LoginCredentials {
  email: string;
  name: string;
}

export async function login(credentials: LoginCredentials) {
  try {
    const response = await apiRequest("POST", "/api/auth/login", credentials);
    const user = await response.json();
    
    // Invalidate the current user query to trigger a refetch
    queryClient.invalidateQueries({ queryKey: ["/api/auth/current"] });
    
    return user;
  } catch (error) {
    throw new Error("Failed to login. Please check your credentials and try again.");
  }
}

export async function loginWithGoogle() {
  try {
    // In a real implementation, this would redirect to Google OAuth
    // For now, we'll simulate it with our mock endpoint
    const mockGoogleCredentials = {
      email: "google-user@example.com",
      password: "google-auth", // This wouldn't be needed in a real implementation
    };
    
    const response = await apiRequest("POST", "/api/auth/google", mockGoogleCredentials);
    const user = await response.json();
    
    // Invalidate the current user query to trigger a refetch
    queryClient.invalidateQueries({ queryKey: ["/api/auth/current"] });
    
    return user;
  } catch (error) {
    throw new Error("Failed to login with Google. Please try again.");
  }
}

export async function register(credentials: RegisterCredentials) {
  try {
    const response = await apiRequest("POST", "/api/auth/register", credentials);
    const user = await response.json();
    
    // Invalidate the current user query to trigger a refetch
    queryClient.invalidateQueries({ queryKey: ["/api/auth/current"] });
    
    return user;
  } catch (error) {
    if (error instanceof Response) {
      const data = await error.json();
      throw new Error(data.message || "Registration failed. Please try again.");
    }
    throw new Error("Registration failed. Please try again.");
  }
}

export async function logout() {
  try {
    await apiRequest("POST", "/api/auth/logout");
    
    // Clear all queries from the cache to force a complete reset
    queryClient.clear();
    
    // Force reload the page to ensure a clean state
    window.location.href = "/";
    
    return true;
  } catch (error) {
    throw new Error("Failed to logout. Please try again.");
  }
}
