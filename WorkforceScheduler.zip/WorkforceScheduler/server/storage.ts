import {
  users, type User, type InsertUser,
  workerTypes, type WorkerType, type InsertWorkerType,
  workers, type Worker, type InsertWorker,
  availability, type Availability, type InsertAvailability,
  shifts, type Shift, type InsertShift,
  shiftRequirements, type ShiftRequirement, type InsertShiftRequirement,
  shiftAssignments, type ShiftAssignment, type InsertShiftAssignment,
  activities, type Activity, type InsertActivity
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Worker Type operations
  getWorkerTypes(userId: number): Promise<WorkerType[]>;
  getWorkerType(id: number): Promise<WorkerType | undefined>;
  createWorkerType(workerType: InsertWorkerType): Promise<WorkerType>;
  updateWorkerType(id: number, workerType: Partial<InsertWorkerType>): Promise<WorkerType | undefined>;
  deleteWorkerType(id: number): Promise<boolean>;
  
  // Worker operations
  getWorkers(userId: number): Promise<Worker[]>;
  getWorker(id: number): Promise<Worker | undefined>;
  createWorker(worker: InsertWorker): Promise<Worker>;
  updateWorker(id: number, worker: Partial<InsertWorker>): Promise<Worker | undefined>;
  deleteWorker(id: number): Promise<boolean>;
  
  // Availability operations
  getAvailabilityForWorker(workerId: number): Promise<Availability[]>;
  getAvailabilityForDate(date: Date): Promise<Availability[]>;
  createAvailability(availability: InsertAvailability): Promise<Availability>;
  bulkCreateAvailability(availabilities: InsertAvailability[]): Promise<Availability[]>;
  
  // Shift operations
  getShifts(userId: number): Promise<Shift[]>;
  getShiftsByDate(userId: number, date: Date): Promise<Shift[]>;
  getShiftsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<Shift[]>;
  getShift(id: number): Promise<Shift | undefined>;
  createShift(shift: InsertShift): Promise<Shift>;
  updateShift(id: number, shift: Partial<InsertShift>): Promise<Shift | undefined>;
  deleteShift(id: number): Promise<boolean>;
  
  // Shift requirements operations
  getRequirementsForShift(shiftId: number): Promise<ShiftRequirement[]>;
  createShiftRequirement(requirement: InsertShiftRequirement): Promise<ShiftRequirement>;
  updateShiftRequirement(id: number, requirement: Partial<InsertShiftRequirement>): Promise<ShiftRequirement | undefined>;
  deleteShiftRequirement(id: number): Promise<boolean>;
  
  // Shift assignments operations
  getAssignmentsForShift(shiftId: number): Promise<ShiftAssignment[]>;
  createShiftAssignment(assignment: InsertShiftAssignment): Promise<ShiftAssignment>;
  deleteShiftAssignment(id: number): Promise<boolean>;
  
  // Activity operations
  getActivities(userId: number, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

// Helper functions for date handling
function getDateString(dateInput: unknown): string {
  if (typeof dateInput === 'string') {
    return dateInput;
  } else if (dateInput instanceof Date) {
    return dateInput.toISOString().split('T')[0];
  } else {
    // Fallback for any other type
    return String(dateInput);
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private workerTypes: Map<number, WorkerType>;
  private workers: Map<number, Worker>;
  private availabilities: Map<number, Availability>;
  private shifts: Map<number, Shift>;
  private shiftRequirements: Map<number, ShiftRequirement>;
  private shiftAssignments: Map<number, ShiftAssignment>;
  private activities: Map<number, Activity>;
  
  private currentIds: {
    user: number;
    workerType: number;
    worker: number;
    availability: number;
    shift: number;
    shiftRequirement: number;
    shiftAssignment: number;
    activity: number;
  };

  constructor() {
    this.users = new Map();
    this.workerTypes = new Map();
    this.workers = new Map();
    this.availabilities = new Map();
    this.shifts = new Map();
    this.shiftRequirements = new Map();
    this.shiftAssignments = new Map();
    this.activities = new Map();
    
    this.currentIds = {
      user: 1,
      workerType: 1,
      worker: 1,
      availability: 1,
      shift: 1,
      shiftRequirement: 1,
      shiftAssignment: 1,
      activity: 1
    };
    
    // Add default worker types
    this.createWorkerType({
      name: "General",
      description: "General-purpose workers for basic tasks",
      color: "#3b82f6", // blue
      userId: 1 
    });
    
    this.createWorkerType({
      name: "Specialized",
      description: "Workers with specialized skills",
      color: "#8b5cf6", // purple
      userId: 1
    });
    
    this.createWorkerType({
      name: "Supervisor",
      description: "Team leaders and supervisors",
      color: "#10b981", // green
      userId: 1
    });
    
    // Add a sample shift for today synchronously for initial data
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    
    // Create a shift directly without using async method
    const shiftId = this.currentIds.shift++;
    const sampleShift = { 
      name: "Morning Shift",
      date: todayStr,
      startTime: "08:00",
      endTime: "12:00",
      location: "Main Facility",
      notes: "Sample shift for testing",
      userId: 1,
      id: shiftId
    };
    this.shifts.set(shiftId, sampleShift);
    
    // Add requirements for the sample shift directly
    const req1Id = this.currentIds.shiftRequirement++;
    this.shiftRequirements.set(req1Id, {
      id: req1Id,
      shiftId: shiftId,
      workerType: "General",
      count: 3
    });
    
    const req2Id = this.currentIds.shiftRequirement++;
    this.shiftRequirements.set(req2Id, {
      id: req2Id,
      shiftId: shiftId,
      workerType: "Specialized",
      count: 1
    });
    
    const req3Id = this.currentIds.shiftRequirement++;
    this.shiftRequirements.set(req3Id, {
      id: req3Id,
      shiftId: shiftId,
      workerType: "Supervisor",
      count: 1
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.googleId === googleId
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.user++;
    const user: User = { 
      ...insertUser, 
      id,
      avatar: insertUser.avatar || null,
      googleId: insertUser.googleId || null
    };
    this.users.set(id, user);
    return user;
  }
  
  // Worker Type operations
  async getWorkerTypes(userId: number): Promise<WorkerType[]> {
    return Array.from(this.workerTypes.values()).filter(
      (type) => type.userId === userId
    );
  }

  async getWorkerType(id: number): Promise<WorkerType | undefined> {
    return this.workerTypes.get(id);
  }

  async createWorkerType(insertWorkerType: InsertWorkerType): Promise<WorkerType> {
    const id = this.currentIds.workerType++;
    const workerType: WorkerType = { 
      ...insertWorkerType, 
      id,
      color: insertWorkerType.color || "#3b82f6",
      description: insertWorkerType.description || null
    };
    this.workerTypes.set(id, workerType);
    return workerType;
  }

  async updateWorkerType(id: number, workerTypeUpdate: Partial<InsertWorkerType>): Promise<WorkerType | undefined> {
    const workerType = this.workerTypes.get(id);
    if (!workerType) return undefined;
    
    const updatedWorkerType = { ...workerType, ...workerTypeUpdate };
    this.workerTypes.set(id, updatedWorkerType);
    return updatedWorkerType;
  }

  async deleteWorkerType(id: number): Promise<boolean> {
    return this.workerTypes.delete(id);
  }

  // Worker operations
  async getWorkers(userId: number): Promise<Worker[]> {
    return Array.from(this.workers.values()).filter(
      (worker) => worker.userId === userId
    );
  }

  async getWorker(id: number): Promise<Worker | undefined> {
    return this.workers.get(id);
  }

  async createWorker(insertWorker: InsertWorker): Promise<Worker> {
    const id = this.currentIds.worker++;
    const worker: Worker = { 
      ...insertWorker, 
      id,
      email: insertWorker.email || null,
      phone: insertWorker.phone || null
    };
    this.workers.set(id, worker);
    return worker;
  }

  async updateWorker(id: number, workerUpdate: Partial<InsertWorker>): Promise<Worker | undefined> {
    const worker = this.workers.get(id);
    if (!worker) return undefined;
    
    const updatedWorker = { ...worker, ...workerUpdate };
    this.workers.set(id, updatedWorker);
    return updatedWorker;
  }

  async deleteWorker(id: number): Promise<boolean> {
    return this.workers.delete(id);
  }

  // Availability operations
  async getAvailabilityForWorker(workerId: number): Promise<Availability[]> {
    return Array.from(this.availabilities.values()).filter(
      (a) => a.workerId === workerId
    );
  }

  async getAvailabilityForDate(date: Date): Promise<Availability[]> {
    const dateString = date.toISOString().split('T')[0];
    return Array.from(this.availabilities.values()).filter(
      (a) => {
        return getDateString(a.date) === dateString;
      }
    );
  }

  async createAvailability(insertAvailability: InsertAvailability): Promise<Availability> {
    const id = this.currentIds.availability++;
    const availability: Availability = { 
      ...insertAvailability, 
      id,
      startTime: insertAvailability.startTime || null,
      endTime: insertAvailability.endTime || null,
      notes: insertAvailability.notes || null
    };
    this.availabilities.set(id, availability);
    return availability;
  }

  async bulkCreateAvailability(availabilities: InsertAvailability[]): Promise<Availability[]> {
    const createdAvailabilities: Availability[] = [];
    
    for (const insertAvailability of availabilities) {
      const id = this.currentIds.availability++;
      const availability: Availability = { 
        ...insertAvailability, 
        id,
        startTime: insertAvailability.startTime || null,
        endTime: insertAvailability.endTime || null,
        notes: insertAvailability.notes || null
      };
      this.availabilities.set(id, availability);
      createdAvailabilities.push(availability);
    }
    
    return createdAvailabilities;
  }

  // Shift operations
  async getShifts(userId: number): Promise<Shift[]> {
    return Array.from(this.shifts.values()).filter(
      (shift) => shift.userId === userId
    );
  }

  async getShiftsByDate(userId: number, date: Date): Promise<Shift[]> {
    const dateString = date.toISOString().split('T')[0];
    return Array.from(this.shifts.values()).filter(
      (shift) => {
        if (shift.userId !== userId) return false;
        return getDateString(shift.date) === dateString;
      }
    );
  }

  async getShiftsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<Shift[]> {
    const startDateStr = startDate.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];
    
    return Array.from(this.shifts.values()).filter(
      (shift) => {
        if (shift.userId !== userId) return false;
        const shiftDateStr = getDateString(shift.date);
        return shiftDateStr >= startDateStr && shiftDateStr <= endDateStr;
      }
    );
  }

  async getShift(id: number): Promise<Shift | undefined> {
    return this.shifts.get(id);
  }

  async createShift(insertShift: InsertShift): Promise<Shift> {
    const id = this.currentIds.shift++;
    const shift: Shift = { 
      ...insertShift, 
      id,
      location: insertShift.location || null,
      notes: insertShift.notes || null
    };
    this.shifts.set(id, shift);
    return shift;
  }

  async updateShift(id: number, shiftUpdate: Partial<InsertShift>): Promise<Shift | undefined> {
    const shift = this.shifts.get(id);
    if (!shift) return undefined;
    
    const updatedShift = { ...shift, ...shiftUpdate };
    this.shifts.set(id, updatedShift);
    return updatedShift;
  }

  async deleteShift(id: number): Promise<boolean> {
    return this.shifts.delete(id);
  }

  // Shift requirements operations
  async getRequirementsForShift(shiftId: number): Promise<ShiftRequirement[]> {
    return Array.from(this.shiftRequirements.values()).filter(
      (req) => req.shiftId === shiftId
    );
  }

  async createShiftRequirement(insertRequirement: InsertShiftRequirement): Promise<ShiftRequirement> {
    const id = this.currentIds.shiftRequirement++;
    const requirement: ShiftRequirement = { ...insertRequirement, id };
    this.shiftRequirements.set(id, requirement);
    return requirement;
  }

  async updateShiftRequirement(id: number, reqUpdate: Partial<InsertShiftRequirement>): Promise<ShiftRequirement | undefined> {
    const requirement = this.shiftRequirements.get(id);
    if (!requirement) return undefined;
    
    const updatedRequirement = { ...requirement, ...reqUpdate };
    this.shiftRequirements.set(id, updatedRequirement);
    return updatedRequirement;
  }

  async deleteShiftRequirement(id: number): Promise<boolean> {
    return this.shiftRequirements.delete(id);
  }

  // Shift assignments operations
  async getAssignmentsForShift(shiftId: number): Promise<ShiftAssignment[]> {
    return Array.from(this.shiftAssignments.values()).filter(
      (assign) => assign.shiftId === shiftId
    );
  }

  async createShiftAssignment(insertAssignment: InsertShiftAssignment): Promise<ShiftAssignment> {
    const id = this.currentIds.shiftAssignment++;
    const assignment: ShiftAssignment = { ...insertAssignment, id };
    this.shiftAssignments.set(id, assignment);
    return assignment;
  }

  async deleteShiftAssignment(id: number): Promise<boolean> {
    return this.shiftAssignments.delete(id);
  }

  // Activity operations
  async getActivities(userId: number, limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .filter((activity) => activity.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return limit ? activities.slice(0, limit) : activities;
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentIds.activity++;
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      timestamp: new Date() 
    };
    this.activities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();
