import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Strategy as GoogleStrategy } from "passport-local";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertWorkerSchema, 
  insertShiftSchema, 
  insertShiftRequirementSchema,
  insertActivitySchema
} from "@shared/schema";
import MemoryStore from "memorystore";

// Mock Google strategy since we don't have actual Google credentials
// In a real implementation, you would use passport-google-oauth20
const MockGoogleStrategy = (options: any, verify: any) => {
  return new LocalStrategy(
    { usernameField: "email", passwordField: "password" },
    async (email, password, done) => {
      try {
        const user = await storage.getUserByEmail(email);
        if (user) {
          return done(null, user);
        }
        
        // Create a new user with Google auth
        const newUser = await storage.createUser({
          username: email.split("@")[0],
          password: "google-auth", // This would normally not be stored
          email,
          name: email.split("@")[0],
          googleId: `google-${Date.now()}`,
          avatar: null
        });
        
        return done(null, newUser);
      } catch (error) {
        return done(error);
      }
    }
  );
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const MemorySessionStore = MemoryStore(session);
  
  // Set up session
  app.use(session({
    secret: "staff-sync-secret",
    resave: false,
    saveUninitialized: false,
    store: new MemorySessionStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: {
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));
  
  // Set up passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });
  
  // Set up local strategy
  passport.use(new LocalStrategy(
    async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || user.password !== password) {
          return done(null, false, { message: "Incorrect username or password" });
        }
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  ));
  
  // Set up Google strategy (mock)
  passport.use("google", MockGoogleStrategy(
    {
      clientID: "mock-google-client-id",
      clientSecret: "mock-google-client-secret",
      callbackURL: "/api/auth/google/callback"
    },
    async (_accessToken: string, _refreshToken: string, profile: any, done: any) => {
      try {
        let user = await storage.getUserByGoogleId(profile.id);
        
        if (!user) {
          user = await storage.createUser({
            username: profile.emails[0].value.split("@")[0],
            password: "google-auth", // This would normally not be stored
            email: profile.emails[0].value,
            name: profile.displayName,
            googleId: profile.id,
            avatar: profile.photos?.[0]?.value || null
          });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  ));
  
  // Auth middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Not authenticated" });
  };
  
  // Auth routes
  app.post("/api/auth/login", 
    passport.authenticate("local"),
    (req, res) => {
      res.json(req.user);
    }
  );
  
  app.post("/api/auth/google", 
    passport.authenticate("google"),
    (req, res) => {
      res.json(req.user);
    }
  );
  
  app.get("/api/auth/current", (req, res) => {
    if (req.isAuthenticated()) {
      res.json(req.user);
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Auto login after registration
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in after registration" });
        }
        return res.json(user);
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Worker routes
  app.get("/api/workers", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const workers = await storage.getWorkers(user.id);
      res.json(workers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching workers" });
    }
  });
  
  app.post("/api/workers", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const workerData = insertWorkerSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const worker = await storage.createWorker(workerData);
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "create",
        description: `Created worker: ${worker.name}`
      });
      
      res.json(worker);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Availability routes
  app.post("/api/availability/upload", isAuthenticated, async (req, res) => {
    // This would normally parse an Excel file
    // For now, we'll just accept JSON data
    try {
      const user = req.user as any;
      const { workerId, availabilities } = req.body;
      
      if (!Array.isArray(availabilities)) {
        return res.status(400).json({ message: "Invalid availability data" });
      }
      
      const createdAvailabilities = await storage.bulkCreateAvailability(
        availabilities.map(avail => ({
          workerId,
          date: avail.date instanceof Date ? avail.date.toISOString().split('T')[0] : avail.date,
          isAvailable: avail.isAvailable,
          startTime: avail.startTime || null,
          endTime: avail.endTime || null,
          notes: avail.notes || null
        }))
      );
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "upload",
        description: `Uploaded availability for worker ID: ${workerId}`
      });
      
      res.json(createdAvailabilities);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  app.get("/api/availability/:workerId", isAuthenticated, async (req, res) => {
    try {
      const workerId = parseInt(req.params.workerId);
      const availability = await storage.getAvailabilityForWorker(workerId);
      res.json(availability);
    } catch (error) {
      res.status(500).json({ message: "Error fetching availability" });
    }
  });
  
  // Shift routes
  app.get("/api/shifts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const shifts = await storage.getShifts(user.id);
      res.json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching shifts" });
    }
  });
  
  app.get("/api/shifts/date/:date", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const date = new Date(req.params.date);
      const shifts = await storage.getShiftsByDate(user.id, date);
      res.json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching shifts" });
    }
  });
  
  app.get("/api/shifts/range", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      // Get start and end dates from query parameters
      const startDate = req.query.start ? new Date(req.query.start as string) : new Date();
      const endDate = req.query.end ? new Date(req.query.end as string) : new Date();
      
      console.log("Fetching shifts in range:", {
        userId: user.id,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString()
      });
      
      const shifts = await storage.getShiftsByDateRange(user.id, startDate, endDate);
      console.log(`Found ${shifts.length} shifts in range`);
      
      res.json(shifts);
    } catch (error) {
      console.error("Error fetching shifts by range:", error);
      res.status(500).json({ message: "Error fetching shifts" });
    }
  });
  
  app.post("/api/shifts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      console.log("Creating new shift with data:", {
        ...req.body,
        date: req.body.date,
        userId: user.id
      });
      
      const shiftData = insertShiftSchema.parse({
        ...req.body,
        userId: user.id,
        date: req.body.date, // Keep the date as a string
      });
      
      const shift = await storage.createShift(shiftData);
      console.log("Shift created successfully:", shift);
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "create",
        description: `Created shift: ${shift.name} on ${shift.date}`
      });
      
      res.json(shift);
    } catch (error) {
      console.error("Error creating shift:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  app.patch("/api/shifts/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const shiftId = parseInt(req.params.id);
      
      // Verify the shift exists and belongs to this user
      const existingShift = await storage.getShift(shiftId);
      if (!existingShift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      if (existingShift.userId !== user.id) {
        return res.status(403).json({ message: "You don't have permission to modify this shift" });
      }
      
      console.log("Updating shift:", shiftId, "with data:", req.body);
      
      // For update, we don't need to re-validate all fields, just the ones being updated
      const shiftUpdateData = {
        ...req.body,
        userId: user.id // Ensure userId stays the same
      };
      
      const updatedShift = await storage.updateShift(shiftId, shiftUpdateData);
      
      if (!updatedShift) {
        return res.status(500).json({ message: "Failed to update shift" });
      }
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "update",
        description: `Updated shift: ${updatedShift.name} on ${updatedShift.date}`
      });
      
      res.json(updatedShift);
    } catch (error) {
      console.error("Error updating shift:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Shift requirements routes
  app.get("/api/requirements/:shiftId", isAuthenticated, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.shiftId);
      const requirements = await storage.getRequirementsForShift(shiftId);
      res.json(requirements);
    } catch (error) {
      res.status(500).json({ message: "Error fetching requirements" });
    }
  });
  
  app.post("/api/requirements", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const requirementData = insertShiftRequirementSchema.parse(req.body);
      
      // Verify the user owns the shift being modified
      const shift = await storage.getShift(requirementData.shiftId);
      if (!shift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      if (shift.userId !== user.id) {
        return res.status(403).json({ message: "You don't have permission to modify this shift" });
      }
      
      const requirement = await storage.createShiftRequirement(requirementData);
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "create",
        description: `Added requirement for ${requirementData.count} ${requirementData.workerType} workers to shift: ${shift.name}`
      });
      
      res.json(requirement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  app.patch("/api/requirements/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const requirementId = parseInt(req.params.id);
      
      // Get the requirement first
      const requirement = await storage.getRequirementsForShift(requirementId);
      if (!requirement || requirement.length === 0) {
        return res.status(404).json({ message: "Requirement not found" });
      }
      
      // Check if the user owns the shift this requirement belongs to
      const shift = await storage.getShift(requirement[0].shiftId);
      if (!shift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      if (shift.userId !== user.id) {
        return res.status(403).json({ message: "You don't have permission to modify this requirement" });
      }
      
      // Update the requirement
      const updatedRequirement = await storage.updateShiftRequirement(requirementId, req.body);
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "update",
        description: `Updated requirement for ${req.body.count} ${req.body.workerType} workers on shift: ${shift.name}`
      });
      
      res.json(updatedRequirement);
    } catch (error) {
      console.error("Error updating requirement:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  app.delete("/api/requirements/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const requirementId = parseInt(req.params.id);
      
      // Get all requirements for this shift to find the one we want to delete
      const allRequirements = await storage.getRequirementsForShift(requirementId);
      const requirement = allRequirements.find(r => r.id === requirementId);
      
      if (!requirement) {
        return res.status(404).json({ message: "Requirement not found" });
      }
      
      // Check if the user owns the shift this requirement belongs to
      const shift = await storage.getShift(requirement.shiftId);
      if (!shift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      if (shift.userId !== user.id) {
        return res.status(403).json({ message: "You don't have permission to delete this requirement" });
      }
      
      // Delete the requirement
      await storage.deleteShiftRequirement(requirementId);
      
      // Create activity log
      await storage.createActivity({
        userId: user.id,
        activityType: "delete",
        description: `Removed requirement for ${requirement.workerType} workers from shift: ${shift.name}`
      });
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting requirement:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Worker Types routes
  app.get("/api/worker-types", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const workerTypes = await storage.getWorkerTypes(user.id);
      res.json(workerTypes);
    } catch (error) {
      res.status(500).json({ message: "Error fetching worker types" });
    }
  });
  
  app.post("/api/worker-types", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const insertWorkerType = { 
        ...req.body, 
        userId: user.id 
      };
      
      const workerType = await storage.createWorkerType(insertWorkerType);
      
      await storage.createActivity({
        userId: user.id,
        activityType: 'create',
        description: `Created new worker type: ${workerType.name}`
      });
      
      res.status(201).json(workerType);
    } catch (error) {
      console.error("Error creating worker type:", error);
      res.status(400).json({ message: "Error creating worker type" });
    }
  });
  
  app.patch("/api/worker-types/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const id = parseInt(req.params.id);
      
      const workerType = await storage.getWorkerType(id);
      if (!workerType) {
        return res.status(404).json({ message: "Worker type not found" });
      }
      
      if (workerType.userId !== user.id) {
        return res.status(403).json({ message: "Unauthorized to update this worker type" });
      }
      
      const updatedWorkerType = await storage.updateWorkerType(id, req.body);
      
      await storage.createActivity({
        userId: user.id,
        activityType: 'update',
        description: `Updated worker type: ${updatedWorkerType!.name}`
      });
      
      res.json(updatedWorkerType);
    } catch (error) {
      console.error("Error updating worker type:", error);
      res.status(400).json({ message: "Error updating worker type" });
    }
  });
  
  app.delete("/api/worker-types/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const id = parseInt(req.params.id);
      
      const workerType = await storage.getWorkerType(id);
      if (!workerType) {
        return res.status(404).json({ message: "Worker type not found" });
      }
      
      if (workerType.userId !== user.id) {
        return res.status(403).json({ message: "Unauthorized to delete this worker type" });
      }
      
      // Check if this worker type is being used by any workers or shift requirements
      const workers = await storage.getWorkers(user.id);
      const workerUsesType = workers.some(worker => worker.type === workerType.name);
      
      if (workerUsesType) {
        return res.status(400).json({ 
          message: "Cannot delete this worker type because it is being used by one or more workers" 
        });
      }
      
      await storage.deleteWorkerType(id);
      
      await storage.createActivity({
        userId: user.id,
        activityType: 'delete',
        description: `Deleted worker type: ${workerType.name}`
      });
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting worker type:", error);
      res.status(400).json({ message: "Error deleting worker type" });
    }
  });
  
  // Activity routes
  app.get("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const activities = await storage.getActivities(user.id, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Error fetching activities" });
    }
  });
  
  return httpServer;
}
